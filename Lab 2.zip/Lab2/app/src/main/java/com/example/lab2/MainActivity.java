package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Spinner spSelectionForCounting;
    private EditText userEnterTextHere;
    private TextView CharCount;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.userEnterTextHere = findViewById(R.id.userEnterTextHere);
        this.CharCount = findViewById(R.id.CharCount);
        this.spSelectionForCounting = (Spinner) findViewById(R.id.spSelectionForCounting);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource( this, R.array.selection_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSelectionForCounting.setAdapter(adapter);

        textView = (TextView) findViewById(R.id.textView);
        editText = (EditText) findViewById(R.id.editText);



        public void CharCount(view View) {

            String spinnerSelection = spSelectionForCounting.getSelectedItem().toString();
            String selectWordCount = getResources().getString(R.string.selection_chars);

            if(spinnerSelection.equalsIgnoreCase(selectWordCount)){
                String userDialogBox = String.valueOf(this.userEnterTextHere.getText().toString());
                int enteredTextLenghtInWords = userEnterTextHere.length();
                this.CharCount.getText().toString().length();
            }

            }
            else{
            Toast.makeText( this, "Not implemented", Toast.LENGTH_LONG).show();
            }

        }
    }